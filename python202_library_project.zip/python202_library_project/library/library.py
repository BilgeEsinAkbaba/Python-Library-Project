from __future__ import annotations
import json
from pathlib import Path
from typing import List, Optional
import httpx

from .models import Book

OPEN_LIBRARY_URL = "https://openlibrary.org/isbn/{isbn}.json"


class Library:
    def __init__(self, storage_file: str = "library.json"):
        self.storage_path = Path(storage_file)
        self.books: List[Book] = []
        self.load_books()

    # ---------- Persistence ----------
    def load_books(self) -> None:
        if self.storage_path.exists():
            try:
                data = json.loads(self.storage_path.read_text(encoding="utf-8"))
                self.books = [Book.from_dict(item) for item in data]
            except json.JSONDecodeError:
                self.books = []
        else:
            self.books = []

    def save_books(self) -> None:
        data = [b.to_dict() for b in self.books]
        self.storage_path.write_text(
            json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8"
        )

    # ---------- Core operations ----------
    def add_book(self, book: Book) -> None:
        if self.find_book(book.isbn):
            raise ValueError("Book with this ISBN already exists.")
        self.books.append(book)
        self.save_books()

    def add_book_from_isbn(self, isbn: str) -> Book:
        """
        ISBN ile kitap ekler. Önce API'den dener, olmazsa varsayılan kitap ekler.
        """
        fetched = self.fetch_book_by_isbn(isbn)
        if fetched is None:
            print("⚠️ API'den veri alınamadı. Varsayılan kitap ekleniyor...")
            fetched = Book(title=f"Kitap-{isbn}", author="Bilinmeyen Yazar", isbn=isbn)
        self.add_book(fetched)
        return fetched

    def remove_book(self, isbn: str) -> bool:
        before = len(self.books)
        self.books = [b for b in self.books if b.isbn != isbn]
        changed = len(self.books) != before
        if changed:
            self.save_books()
        return changed

    def list_books(self) -> List[Book]:
        return list(self.books)

    def find_book(self, isbn: str) -> Optional[Book]:
        for b in self.books:
            if b.isbn == isbn:
                return b
        return None

    # ---------- External API ----------
    def fetch_book_by_isbn(self, isbn: str) -> Optional[Book]:
        url = OPEN_LIBRARY_URL.format(isbn=isbn.replace("-", ""))
        headers = {"User-Agent": "Python Library Client"}

        try:
            # 302 redirect takip edilecek şekilde
            resp = httpx.get(url, headers=headers, timeout=10.0, follow_redirects=True)
            if resp.status_code == 404:
                return None
            resp.raise_for_status()
            data = resp.json()
        except (httpx.RequestError, httpx.HTTPStatusError) as e:
            print(f"HTTP hatası: {e}")
            return None

        title = data.get("title")
        author_name = "Unknown Author"

        authors = data.get("authors", [])
        if authors and isinstance(authors, list):
            first_author = authors[0]
            if "name" in first_author:
                author_name = first_author["name"]
            elif "key" in first_author:
                author_name = self.get_author_name(first_author["key"], headers)

        if not title:
            return None

        return Book(title=title, author=author_name, isbn=isbn)

    def get_author_name(self, author_key: str, headers: dict) -> str:
        url = f"https://openlibrary.org{author_key}.json"
        try:
            resp = httpx.get(url, headers=headers, timeout=10.0)
            resp.raise_for_status()
            data = resp.json()
            return data.get("name", "Unknown Author")
        except httpx.RequestError:
            return "Unknown Author"
