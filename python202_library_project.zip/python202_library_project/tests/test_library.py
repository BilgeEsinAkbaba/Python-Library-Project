
import json
from pathlib import Path
from library.library import Library
from library.models import Book

def test_add_list_remove(tmp_path: Path, monkeypatch):
    storage = tmp_path / "lib.json"
    lib = Library(str(storage))

    # Simulate fetch by bypassing http call
    def fake_fetch(isbn: str):
        return Book(title="Test Book", author="Tester", isbn=isbn)
    monkeypatch.setattr(lib, "fetch_book_by_isbn", fake_fetch)

    # add
    book = lib.add_book_from_isbn("1234567890")
    assert book.title == "Test Book"
    assert len(lib.list_books()) == 1

    # persist
    assert storage.exists()
    data = json.loads(storage.read_text(encoding="utf-8"))
    assert data[0]["isbn"] == "1234567890"

    # duplicate
    import pytest
    with pytest.raises(ValueError):
        lib.add_book_from_isbn("1234567890")

    # remove
    ok = lib.remove_book("1234567890")
    assert ok
    assert len(lib.list_books()) == 0
