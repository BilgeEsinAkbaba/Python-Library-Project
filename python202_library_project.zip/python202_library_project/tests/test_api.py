
from fastapi.testclient import TestClient
from api import app, lib
from library.models import Book

client = TestClient(app)

def test_post_books_and_get(monkeypatch):
    # fake external fetch
    def fake_fetch(isbn: str):
        return Book(title="API Book", author="API Author", isbn=isbn)
    monkeypatch.setattr(lib, "fetch_book_by_isbn", fake_fetch)

    # ensure clean state
    for b in list(lib.list_books()):
        lib.remove_book(b.isbn)

    # POST
    res = client.post("/books", json={"isbn": "999"})
    assert res.status_code == 201
    assert res.json()["title"] == "API Book"

    # GET
    res = client.get("/books")
    assert res.status_code == 200
    assert any(b["isbn"] == "999" for b in res.json())

def test_delete_book():
    # ensure exists (direct add without fetch)
    lib.add_book(Book(title="Del", author="Me", isbn="111"))
    res = client.delete("/books/111")
    assert res.status_code == 204
