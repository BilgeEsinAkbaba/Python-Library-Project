import httpx

isbn = "9780140328721"
url = f"https://openlibrary.org/isbn/{isbn}.json"

headers = {"User-Agent": "Python Library Client"}

try:
    resp = httpx.get(url, headers=headers, timeout=10.0)
    resp.raise_for_status()
    data = resp.json()
    print("Başlık:", data.get("title"))
    authors = data.get("authors", [])
    if authors:
        first = authors[0]
        print("Yazar Key:", first.get("key"))
except httpx.RequestError as e:
    print("HTTP hatası:", e)
except httpx.HTTPStatusError as e:
    print("HTTP durum hatası:", e)