
from library.library import Library
from library.models import Book

def print_menu():
    print("\n--- Kütüphane Uygulaması ---")
    print("1. Kitap Ekle (ISBN ile)")
    print("2. Kitap Sil")
    print("3. Kitapları Listele")
    print("4. Kitap Ara")
    print("5. Çıkış")

def main():
    lib = Library("library.json")
    while True:
        print_menu()
        choice = input("Seçiminiz: ").strip()
        if choice == "1":
            isbn = input("ISBN: ").strip()
            try:
                book = lib.add_book_from_isbn(isbn)
                print(f"Eklendi: {book}")
            except LookupError:
                print("Kitap bulunamadı veya bağlantı hatası.")
            except ValueError as e:
                print(f"Hata: {e}")
        elif choice == "2":
            isbn = input("Silinecek ISBN: ").strip()
            if lib.remove_book(isbn):
                print("Kitap silindi.")
            else:
                print("Kitap bulunamadı.")
        elif choice == "3":
            books = lib.list_books()
            if not books:
                print("Kütüphanede kitap yok.")
            else:
                for b in books:
                    print("-", b)
        elif choice == "4":
            isbn = input("Aranan ISBN: ").strip()
            book = lib.find_book(isbn)
            if book:
                print(book)
            else:
                print("Kitap bulunamadı.")
        elif choice == "5":
            print("Güle güle!")
            break
        else:
            print("Geçersiz seçim.")

if __name__ == "__main__":
    main()
