
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List

from library.library import Library
from library.models import Book

app = FastAPI(title="Library API", version="1.0.0")
lib = Library("library.json")

class ISBNIn(BaseModel):
    isbn: str

class BookOut(BaseModel):
    title: str
    author: str
    isbn: str

@app.get("/books", response_model=List[BookOut])
def list_books():
    return [BookOut(**b.to_dict()) for b in lib.list_books()]

@app.post("/books", response_model=BookOut, status_code=201)
def add_book(payload: ISBNIn):
    try:
        book = lib.add_book_from_isbn(payload.isbn)
        return BookOut(**book.to_dict())
    except LookupError:
        raise HTTPException(status_code=404, detail="Book not found for given ISBN")
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.delete("/books/{isbn}", status_code=204)
def delete_book(isbn: str):
    ok = lib.remove_book(isbn)
    if not ok:
        raise HTTPException(status_code=404, detail="Book not found")
    return
